import sqlite3
import hashlib
from datetime import datetime


def init_db():
    conn = sqlite3.connect('diabetes_predictions.db')
    c = conn.cursor()

    # Users table
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (username TEXT PRIMARY KEY,
                  password TEXT,
                  name TEXT)''')

    # Predictions table
    c.execute('''CREATE TABLE IF NOT EXISTS predictions
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  username TEXT,
                  prediction_type TEXT,
                  prediction_result TEXT,
                  probability REAL,
                  input_data TEXT,
                  feature_values TEXT,
                  accuracy REAL,
                  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)''')

    # Model history table
    c.execute('''CREATE TABLE IF NOT EXISTS model_history
                 (model_type TEXT,
                  accuracy REAL,
                  model_path TEXT,
                  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)''')

    conn.commit()
    conn.close()


def hash_password(password):
    return hashlib.sha256(str.encode(password)).hexdigest()


def add_user(username, password, name):
    conn = sqlite3.connect('diabetes_predictions.db')
    c = conn.cursor()
    try:
        c.execute("INSERT INTO users VALUES (?,?,?)",
                  (username, hash_password(password), name))
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False
    finally:
        conn.close()


def check_user(username, password):
    conn = sqlite3.connect('diabetes_predictions.db')
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username=? AND password=?",
              (username, hash_password(password)))
    result = c.fetchone()
    conn.close()
    return result is not None


def save_prediction(username, pred_type, result, probability, input_data, feature_values, accuracy):
    conn = sqlite3.connect('diabetes_predictions.db')
    c = conn.cursor()
    c.execute("""INSERT INTO predictions 
                 (username, prediction_type, prediction_result, probability, 
                  input_data, feature_values, accuracy)
                 VALUES (?, ?, ?, ?, ?, ?, ?)""",
              (username, pred_type, result, probability,
               str(input_data), str(feature_values), accuracy))
    conn.commit()
    conn.close()


def get_user_predictions(username):
    conn = sqlite3.connect('diabetes_predictions.db')
    c = conn.cursor()
    c.execute("""SELECT prediction_type, prediction_result, probability, 
                        input_data, feature_values, accuracy, timestamp
                 FROM predictions 
                 WHERE username = ?
                 ORDER BY timestamp DESC""", (username,))
    predictions = c.fetchall()
    conn.close()
    return predictions
