import streamlit as st
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import seaborn as sns


class DiabetesPredictor:
    def __init__(self):
        self.data = None
        self.scaler = None
        self.model = None
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None

    @st.cache_data
    def load_data(self):
        if self.data is None:
            try:
                self.data = pd.read_csv('diabetes_data.csv')
            except FileNotFoundError:
                st.error(
                    "Data file not found. Please check if diabetes_data.csv exists.")
                return False
        return True

    def preprocess_data(self, features):
        if not self.load_data():
            return None, None, None, None

        if self.scaler is None:
            self.scaler = StandardScaler()

        X = self.data[features]
        y = self.data['Diabetes_012']

        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            X, y, test_size=0.2, random_state=42)

        self.X_train_scaled = self.scaler.fit_transform(self.X_train)
        self.X_test_scaled = self.scaler.transform(self.X_test)

        return self.X_train_scaled, self.X_test_scaled, self.y_train, self.y_test

    def train(self):
        raise NotImplementedError("Subclasses must implement train()")

    def predict(self, input_data):
        if self.scaler is None or self.model is None:
            self.train()

        scaled_input = self.scaler.transform(input_data)
        return self.model.predict(scaled_input), self.model.predict_proba(scaled_input)
