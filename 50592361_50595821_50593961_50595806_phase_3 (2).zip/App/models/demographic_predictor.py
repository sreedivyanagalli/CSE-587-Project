import streamlit as st
import pandas as pd
import numpy as np
import sqlite3
import hashlib
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier, AdaBoostClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler, label_binarize
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_curve, auc, accuracy_score, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns

from base_predictor import DiabetesPredictor

class DemographicPredictor(DiabetesPredictor):
    def __init__(self):
        super().__init__()
        self.features = ['Age', 'Sex', 'Education', 'Income', 'BMI']
        self.model = AdaBoostClassifier(
            n_estimators=50, learning_rate=1.0, random_state=42)
