# models/health_predictor.py
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
import streamlit as st

@st.cache_data
def load_diabetes_data():
    """Cache the data loading separately from the class"""
    try:
        return pd.read_csv('diabetes_data.csv')
    except FileNotFoundError:
        st.error("Data file not found. Please check if diabetes_data.csv exists.")
        return None

class BasePredictor:
    def __init__(self):
        self.data = None
        self.scaler = None
        self.model = None
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        self.features = []

    def load_data(self):
        """Load data using cached function"""
        self.data = load_diabetes_data()
        return self.data is not None

    def preprocess_data(self):
        if not self.load_data():
            return None, None, None, None
        
        if self.scaler is None:
            from sklearn.preprocessing import StandardScaler
            self.scaler = StandardScaler()
        
        X = self.data[self.features]
        y = self.data['Diabetes_012']
        
        from sklearn.model_selection import train_test_split
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            X, y, test_size=0.2, random_state=42)
        
        self.X_train_scaled = self.scaler.fit_transform(self.X_train)
        self.X_test_scaled = self.scaler.transform(self.X_test)
        
        return self.X_train_scaled, self.X_test_scaled, self.y_train, self.y_test

    def plot_confusion_matrix(self, y_true, y_pred):
        cm = confusion_matrix(y_true, y_pred)
        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
        plt.title(f'Confusion Matrix - {self.__class__.__name__}')
        plt.xlabel('Predicted')
        plt.ylabel('Actual')
        st.pyplot(plt)

    def plot_feature_importance(self):
        if hasattr(self.model, 'feature_importances_'):
            importance = pd.DataFrame({
                'feature': self.features,
                'importance': self.model.feature_importances_
            })
            importance = importance.sort_values('importance', ascending=False)
            
            plt.figure(figsize=(10, 6))
            sns.barplot(x='importance', y='feature', data=importance)
            plt.title(f'Feature Importance - {self.__class__.__name__}')
            st.pyplot(plt)

    def plot_all_visualizations(self):
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("Feature Importance")
            self.plot_feature_importance()
        
        with col2:
            st.write("Confusion Matrix")
            y_pred = self.model.predict(self.X_test_scaled)
            self.plot_confusion_matrix(self.y_test, y_pred)

class HealthFactorsPredictor(BasePredictor):
    def __init__(self):
        super().__init__()
        self.features = ['HighBP', 'HighChol', 'BMI', 'HeartDiseaseorAttack', 
                        'PhysActivity', 'GenHlth', 'PhysHlth']
        self.model = RandomForestClassifier(
            n_estimators=100,
            max_depth=10,
            random_state=42
        )

    def train(self):
        X_train_scaled, X_test_scaled, y_train, y_test = self.preprocess_data()
        if X_train_scaled is None:
            return None
            
        self.model.fit(X_train_scaled, y_train)
        y_pred = self.model.predict(X_test_scaled)
        return accuracy_score(y_test, y_pred)

    def predict(self, input_data):
        if self.scaler is None or self.model is None:
            self.train()
        
        scaled_input = self.scaler.transform(input_data)
        return self.model.predict(scaled_input), self.model.predict_proba(scaled_input)

class DemographicPredictor(BasePredictor):
    def __init__(self):
        super().__init__()
        self.features = ['Age', 'Sex', 'Education', 'Income', 'BMI']
        self.model = AdaBoostClassifier(
            n_estimators=50,
            learning_rate=1.0,
            random_state=42
        )

    def train(self):
        X_train_scaled, X_test_scaled, y_train, y_test = self.preprocess_data()
        if X_train_scaled is None:
            return None
            
        self.model.fit(X_train_scaled, y_train)
        y_pred = self.model.predict(X_test_scaled)
        return accuracy_score(y_test, y_pred)
    
    def predict(self, input_data):
        if self.scaler is None or self.model is None:
            self.train()

        scaled_input = self.scaler.transform(input_data)
        return self.model.predict(scaled_input), self.model.predict_proba(scaled_input)

class SocioeconomicPredictor(BasePredictor):
    def __init__(self):
        super().__init__()
        self.features = ['Income', 'Education', 'AnyHealthcare', 'NoDocbcCost']
        self.model = RandomForestClassifier(
            n_estimators=100,
            max_depth=None,
            random_state=42
        )

    def train(self):
        X_train_scaled, X_test_scaled, y_train, y_test = self.preprocess_data()
        if X_train_scaled is None:
            return None
            
        self.model.fit(X_train_scaled, y_train)
        y_pred = self.model.predict(X_test_scaled)
        return accuracy_score(y_test, y_pred)
    
    def predict(self, input_data):
        if self.scaler is None or self.model is None:
            self.train()

        scaled_input = self.scaler.transform(input_data)
        return self.model.predict(scaled_input), self.model.predict_proba(scaled_input)

class LifestylePredictor(BasePredictor):
    def __init__(self):
        super().__init__()
        self.features = ['PhysActivity', 'Fruits', 'Veggies', 
                        'HvyAlcoholConsump', 'Smoker', 'BMI']
        self.model = LogisticRegression(
            max_iter=1000,
            random_state=42
        )

    def train(self):
        X_train_scaled, X_test_scaled, y_train, y_test = self.preprocess_data()
        if X_train_scaled is None:
            return None
            
        self.model.fit(X_train_scaled, y_train)
        y_pred = self.model.predict(X_test_scaled)
        return accuracy_score(y_test, y_pred)
    
    def predict(self, input_data):
        if self.scaler is None or self.model is None:
            self.train()

        scaled_input = self.scaler.transform(input_data)
        return self.model.predict(scaled_input), self.model.predict_proba(scaled_input)
