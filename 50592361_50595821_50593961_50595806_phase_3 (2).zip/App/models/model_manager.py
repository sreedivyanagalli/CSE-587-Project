import os
import joblib
from datetime import datetime

class ModelManager:
    def __init__(self):
        self.models_dir = 'saved_models'
        os.makedirs(self.models_dir, exist_ok=True)

    def save_model(self, model, model_type, accuracy, features, scaler):
        """Save model with its metadata"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        model_filename = f"{model_type}_{accuracy:.3f}_{timestamp}.joblib"
        model_path = os.path.join(self.models_dir, model_filename)
        
        model_data = {
            'model': model,
            'accuracy': accuracy,
            'features': features,
            'scaler': scaler,
            'timestamp': timestamp
        }
        
        joblib.dump(model_data, model_path)
        return model_path

    def load_best_model(self, model_type):
        """Load the best performing model of given type"""
        best_model = None
        best_accuracy = 0
        best_data = None
        
        for filename in os.listdir(self.models_dir):
            if filename.startswith(model_type):
                try:
                    model_path = os.path.join(self.models_dir, filename)
                    model_data = joblib.load(model_path)
                    if model_data['accuracy'] > best_accuracy:
                        best_accuracy = model_data['accuracy']
                        best_data = model_data
                except Exception as e:
                    print(f"Error loading model {filename}: {e}")
                    continue
        
        return best_data