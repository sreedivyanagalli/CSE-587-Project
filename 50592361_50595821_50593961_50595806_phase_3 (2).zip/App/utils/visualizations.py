import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from database import get_user_predictions


def plot_prediction_history(predictions):
    if not predictions:
        return None

    df = pd.DataFrame(predictions,
                      columns=['type', 'result', 'probability', 'input_data',
                               'features', 'accuracy', 'timestamp'])
    df['timestamp'] = pd.to_datetime(df['timestamp'])

    fig = plt.figure(figsize=(15, 10))

    plt.subplot(2, 2, 1)
    pred_counts = df.groupby(['timestamp', 'result']
                             ).size().unstack(fill_value=0)
    pred_counts.plot(kind='bar', stacked=True)
    plt.title('Prediction Results Over Time')
    plt.xticks(rotation=45)

    plt.subplot(2, 2, 2)
    avg_prob = df.groupby('type')['probability'].mean()
    avg_prob.plot(kind='bar')
    plt.title('Average Prediction Probability by Type')
    plt.xticks(rotation=45)

    plt.subplot(2, 2, 3)
    df.plot(x='timestamp', y='accuracy', kind='line')
    plt.title('Model Accuracy Over Time')
    plt.xticks(rotation=45)

    plt.subplot(2, 2, 4)
    df['result'].value_counts().plot(kind='pie', autopct='%1.1f%%')
    plt.title('Distribution of Predictions')

    plt.tight_layout()
    return fig


def render_history_tab(username):
    st.subheader("Prediction History")

    predictions = get_user_predictions(username)
    if not predictions:
        st.write("No prediction history found.")
        return

    total_predictions = len(predictions)
    unique_types = len(set(p[0] for p in predictions))
    avg_accuracy = sum(p[5] for p in predictions) / total_predictions

    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Total Predictions", total_predictions)
    with col2:
        st.metric("Analysis Types Used", unique_types)
    with col3:
        st.metric("Average Accuracy", f"{avg_accuracy:.2%}")

    fig = plot_prediction_history(predictions)
    if fig:
        st.pyplot(fig)

    st.subheader("Detailed History")
    history_df = pd.DataFrame(predictions,
                              columns=['Type', 'Result', 'Probability', 'Input',
                                       'Features', 'Accuracy', 'Timestamp'])
    st.dataframe(history_df)

    if st.button("Export History"):
        csv = history_df.to_csv(index=False)
        st.download_button(
            label="Download CSV",
            data=csv,
            file_name=f"prediction_history_{username}.csv",
            mime="text/csv"
        )
